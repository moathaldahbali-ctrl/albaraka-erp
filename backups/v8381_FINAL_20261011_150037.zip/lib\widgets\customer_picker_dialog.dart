import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CustomerPickerDialog extends StatefulWidget {
  final List<Map<String, dynamic>> customers;
  const CustomerPickerDialog({super.key, required this.customers});

  @override
  State<CustomerPickerDialog> createState() => _CustomerPickerDialogState();
}

class _CustomerPickerDialogState extends State<CustomerPickerDialog> {
  final TextEditingController _ctrl = TextEditingController();
  final ScrollController _scrollCtrl = ScrollController();
  late List<Map<String, dynamic>> _filtered;
  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _filtered = widget.customers;
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _scrollCtrl.dispose();
    super.dispose();
  }

  void _filter(String q) {
    final s = q.trim();
    setState(() {
      if (s.isEmpty) {
        _filtered = widget.customers;
      } else {
        _filtered = widget.customers.where((c) {
          final name = (c['name'] as String? ?? '').toString();
          final phone = (c['phone'] as String? ?? '').toString();
          final code = (c['code'] as String? ?? '').toString();
          return name.contains(s) || phone.contains(s) || code.contains(s);
        }).toList();
      }
      _selectedIndex = 0;
    });
  }

  void _moveSelection(int delta) {
    if (_filtered.isEmpty) return;
    setState(() {
      _selectedIndex = (_selectedIndex + delta).clamp(0, _filtered.length - 1);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToSelected();
    });
  }

  void _scrollToSelected() {
    if (!_scrollCtrl.hasClients) return;
    // v7.1: minimal-scroll + jumpTo (no lag on rapid arrow presses)
    const double itemHeight = 66.0;
    final double viewport = _scrollCtrl.position.viewportDimension;
    final double offset = _scrollCtrl.offset;
    final double itemTop = _selectedIndex * itemHeight;
    final double itemBottom = itemTop + itemHeight;
    double? newOffset;
    if (itemTop < offset) {
      newOffset = itemTop;
    } else if (itemBottom > offset + viewport) {
      newOffset = itemBottom - viewport;
    }
    if (newOffset == null) return;
    final double maxScroll = _scrollCtrl.position.maxScrollExtent;
    final double clamped =
        newOffset < 0 ? 0 : (newOffset > maxScroll ? maxScroll : newOffset);
    _scrollCtrl.jumpTo(clamped);
  }

  void _confirmSelected() {
    if (_filtered.isEmpty) return;
    Navigator.pop(context, _filtered[_selectedIndex]);
  }

  @override
  Widget build(BuildContext context) {
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.arrowDown): () =>
            _moveSelection(1),
        const SingleActivator(LogicalKeyboardKey.arrowUp): () =>
            _moveSelection(-1),
        const SingleActivator(LogicalKeyboardKey.enter):
            _confirmSelected,
        const SingleActivator(LogicalKeyboardKey.numpadEnter):
            _confirmSelected,
      },
      child: Dialog(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560, maxHeight: 620),
          child: Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                color: Colors.grey.shade200,
                child: Row(
                  children: [
                    const Icon(Icons.people),
                    const SizedBox(width: 8),
                    const Text(
                        '\u0627\u062e\u062a\u064a\u0627\u0631 \u0639\u0645\u064a\u0644',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold)),
                    const Spacer(),
                    Text('${_filtered.length}',
                        style: TextStyle(color: Colors.grey.shade600)),
                    const SizedBox(width: 8),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  controller: _ctrl,
                  autofocus: true,
                  onChanged: _filter,
                  onSubmitted: (_) => _confirmSelected(),
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(
                    hintText:
                        '\u0627\u0628\u062d\u062b \u0628\u0627\u0644\u0627\u0633\u0645 \u0623\u0648 \u0627\u0644\u0647\u0627\u062a\u0641 \u0623\u0648 \u0627\u0644\u0643\u0648\u062f...',
                    prefixIcon: Icon(Icons.search),
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: _filtered.isEmpty
                    ? const Center(
                        child: Text(
                            '\u0644\u0627 \u0646\u062a\u0627\u0626\u062c'))
                    : ListView.builder(
                        controller: _scrollCtrl,
                        itemCount: _filtered.length,
                        itemExtent: 66,
                        itemBuilder: (context, i) {
                          final c = _filtered[i];
                          final name =
                              (c['name'] as String? ?? '').toString();
                          final phone =
                              (c['phone'] as String? ?? '').toString();
                          final code =
                              (c['code'] as String? ?? '').toString();
                          final isSelected = i == _selectedIndex;
                          return Container(
                            decoration: BoxDecoration(
                              color: isSelected ? Colors.blue.shade50 : null,
                              border: Border(
                                  bottom: BorderSide(
                                      color: Colors.grey.shade300,
                                      width: 0.5)),
                            ),
                            child: ListTile(
                              dense: true,
                              selected: isSelected,
                              leading: CircleAvatar(
                                radius: 16,
                                child: Text('#$code',
                                    style: const TextStyle(fontSize: 10)),
                              ),
                              title: Text(name),
                              subtitle: phone.isNotEmpty ? Text(phone) : null,
                              onTap: () => Navigator.pop(context, c),
                            ),
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}